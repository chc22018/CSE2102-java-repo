public class GreekPizza extends Pizza {
    public GreekPizza() { this.name = "Greek Pizza"; }
}
