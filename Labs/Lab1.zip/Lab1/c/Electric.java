package c;

public interface Electric {
    void setElectricCostPerKWh(double dollarsPerKWh);
    double getElectricCostPerKWh();

    void setMilesPerKWh(double milesPerKWh);
    double getMilesPerKWh();
}
