public class CheesePizza extends Pizza {
    public CheesePizza() { this.name = "Cheese Pizza"; }
}
