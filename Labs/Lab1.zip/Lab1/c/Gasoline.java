package c;

public interface Gasoline {
    void setGasCostPerGallon(double dollarsPerGallon);
    double getGasCostPerGallon();

    void setMPG(double mpg);
    double getMPG();
}
