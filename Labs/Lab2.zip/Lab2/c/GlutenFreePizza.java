public class GlutenFreePizza extends Pizza {
    public GlutenFreePizza() { this.name = "Gluten Free Pizza"; }
}
