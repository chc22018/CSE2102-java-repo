public class PepperoniPizza extends Pizza {
    public PepperoniPizza() { this.name = "Pepperoni Pizza"; }
}
